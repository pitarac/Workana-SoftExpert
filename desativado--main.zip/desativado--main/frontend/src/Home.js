import React from 'react';

function Home() {
  return (
    <div>
      <h1>Página Inicial</h1>
      <p>Conteúdo da Página Inicial</p>
    </div>
  );
}

export default Home;
